import React from 'react';
import { 
  Sparkles, Play, TrendingUp, Code, Globe, ShieldCheck, Cpu, Layout, 
  GitMerge, Package, MousePointerClick, Zap 
} from 'lucide-react';
import { Button } from './Button';

interface LandingViewProps {
  onStart: () => void;
}

export const LandingView: React.FC<LandingViewProps> = ({ onStart }) => {
  return (
    <div className="animate-fade-in-up space-y-32 w-full max-w-[1500px]">
      {/* HERO */}
      <section className="relative pt-12 lg:pt-20 flex flex-col items-center text-center">
        <div className="absolute top-0 right-10 lg:right-40 w-64 h-64 bg-blue-600/10 rounded-full blur-[80px] -z-10 animate-pulse-slow"></div>
        
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.03] border border-white/10 text-[11px] font-bold tracking-widest text-blue-400 mb-8 hover:bg-white/[0.05] transition-colors cursor-default">
          <Sparkles size={12} /> ARSELL AI ENGINE 2.0
        </div>
        
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-extrabold mb-8 tracking-tight max-w-[1200px] leading-[1.1]">
          <span className="bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400">Geleceğin E-Ticaret</span><br/>
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400">Deneyimini Kurun.</span>
        </h1>
        
        <p className="text-lg md:text-xl text-gray-400 max-w-3xl mb-12 leading-relaxed font-light">
          Kodlama yok. Karmaşık paneller yok. Sadece işinize odaklanın, gerisini <span className="text-white font-medium">Arsell AI</span> saniyeler içinde halletsin.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-5 w-full justify-center relative z-20">
          <Button onClick={onStart} className="px-10 py-4 text-base">Hemen Başla</Button>
          <Button variant="secondary" className="px-10 py-4 text-base">
            <Play size={18} fill="currentColor" /> Tanıtımı İzle
          </Button>
        </div>

        {/* TRUST BADGES */}
        <div className="mt-16 pt-8 border-t border-white/5 w-full max-w-5xl flex flex-col items-center gap-6">
          <span className="text-[10px] text-gray-500 uppercase tracking-widest font-semibold">Resmi Altyapı Partneri</span>
          <img src="https://i.hizliresim.com/5l9cbce.png" alt="Shopify Partner" className="h-10 opacity-60 hover:opacity-100 transition-opacity grayscale hover:grayscale-0 duration-500" />
        </div>

        {/* STATS */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 w-full max-w-[1400px]">
          {[
            { icon: <TrendingUp/>, val: "3X", label: "Daha Fazla Satış" },
            { icon: <Code/>, val: "%0", label: "Kod Bilgisi" },
            { icon: <Globe/>, val: "120+", label: "Ülke Desteği" },
            { icon: <ShieldCheck/>, val: "100%", label: "Güvenli" },
          ].map((stat, i) => (
            <div key={i} className="bg-white/[0.02] border border-white/5 p-6 rounded-2xl flex flex-col items-center justify-center gap-3 hover:bg-white/[0.04] transition-all group cursor-default">
              <div className="text-blue-500 group-hover:scale-110 transition-transform">{stat.icon}</div>
              <span className="text-3xl font-bold text-white">{stat.val}</span>
              <span className="text-xs text-gray-500 font-bold uppercase tracking-wider">{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="py-10 max-w-[1500px] mx-auto scroll-mt-28">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Neden Arsell?</h2>
          <p className="text-gray-400 max-w-xl mx-auto">Geleneksel e-ticaret kurulum süreçlerini unutun. Yeni nesil otomasyonla tanışın.</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { icon: <Cpu/>, title: "AI Optimizasyonu", desc: "Sektörünüze özel en çok satan şablonları ve ürün yerleşimlerini otomatik analiz eder." },
            { icon: <Layout/>, title: "Premium Temalar", desc: "Normalde yüzlerce dolar değerindeki profesyonel temalar kurulumla birlikte gelir." },
            { icon: <ShieldCheck/>, title: "Kurumsal Güvenlik", desc: "Tüm mağazalar SSL sertifikalı ve uluslararası ödeme altyapısına uyumludur." }
          ].map((feat, i) => (
            <div key={i} className="p-8 rounded-3xl bg-gradient-to-b from-white/[0.05] to-transparent border border-white/10 hover:border-blue-500/30 transition-all group">
              <div className="w-14 h-14 bg-black rounded-2xl flex items-center justify-center mb-6 border border-white/10 group-hover:border-blue-500/50 group-hover:shadow-[0_0_20px_rgba(59,130,246,0.3)] transition-all">
                {React.cloneElement(feat.icon as React.ReactElement<any>, { className: "text-white" })}
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">{feat.title}</h3>
              <p className="text-gray-400 leading-relaxed text-sm">{feat.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how-it-works" className="py-10 max-w-[1500px] mx-auto scroll-mt-28">
         <div className="bg-[#050505] border border-white/10 rounded-[3rem] p-8 md:p-16 relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-blue-500 to-transparent opacity-20"></div>
            
            <div className="text-center mb-16 relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Nasıl Çalışır?</h2>
              <p className="text-gray-400 max-w-xl mx-auto">4 adımda sıfırdan profesyonel bir mağazaya.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative z-10">
              {[
                { icon: <MousePointerClick/>, title: "1. Seçim Yap", desc: "Sektörünü belirle ve Arsell'in analiz etmesini bekle." },
                { icon: <GitMerge/>, title: "2. Bağlan", desc: "Shopify hesabını oluşturup sisteme entegre et." },
                { icon: <Cpu/>, title: "3. Üretim", desc: "Yapay zeka mağazanı ve ürünlerini otomatik kurar." },
                { icon: <Package/>, title: "4. Satış", desc: "Mağazan hazır. Sadece pazarlamaya odaklan." }
              ].map((step, i) => (
                <div key={i} className="flex flex-col items-center text-center relative group">
                   {i !== 3 && <div className="hidden md:block absolute top-8 left-[50%] w-full h-[2px] bg-white/5 -z-10"></div>}
                   <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6 text-blue-400 group-hover:scale-110 group-hover:bg-blue-500 group-hover:text-white transition-all duration-300 shadow-xl">
                      {step.icon}
                   </div>
                   <h3 className="text-lg font-bold text-white mb-2">{step.title}</h3>
                   <p className="text-sm text-gray-500 px-2">{step.desc}</p>
                </div>
              ))}
            </div>
         </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-10 max-w-[1000px] mx-auto scroll-mt-28">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Sıkça Sorulan Sorular</h2>
        </div>
        <div className="grid gap-4">
          {[
            { q: "Kurulum gerçekten ücretsiz mi?", a: "Evet, Arsell yazılımını kullanmak tamamen ücretsizdir. Sadece Shopify'ın ilk 3 ay için sunduğu 1$/ay kampanyasından yararlanırsınız." },
            { q: "Teknik bilgiye ihtiyacım var mı?", a: "Hayır. Arsell sizin için tema kurulumunu, ürün yerleşimini ve gerekli ayarları otomatik olarak yapar." },
            { q: "Oluşturulan mağaza kime ait?", a: "Mağaza %100 size aittir. Arsell sadece kurulum aracıdır, mağaza yönetiminde veya gelirlerinde hak iddia etmez." },
            { q: "Dropshipping için uygun mu?", a: "Kesinlikle. Arsell tarafından kurulan temalar ve altyapı dropshipping iş modeli için optimize edilmiştir." }
          ].map((item, i) => (
            <div key={i} className="bg-white/[0.02] border border-white/5 rounded-xl p-6 hover:bg-white/[0.04] transition-colors">
              <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-3">
                <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-xs text-gray-400">?</span>
                {item.q}
              </h3>
              <p className="text-gray-400 text-sm leading-relaxed pl-9">{item.a}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative rounded-[2.5rem] overflow-hidden border border-white/10 p-12 md:p-24 text-center max-w-[1500px] mx-auto">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/40 via-purple-900/20 to-black z-0"></div>
        <div className="relative z-10 max-w-3xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Fırsatı Kaçırma.</h2>
          <p className="text-gray-300 mb-10 text-lg">Binlerce girişimci Arsell ile başladı. Kaybedecek hiçbir şeyin yok, kazanacak çok şeyin var.</p>
          <Button onClick={onStart} className="px-12 py-5 text-lg mx-auto">Hemen Ücretsiz Başla</Button>
        </div>
      </section>
    </div>
  );
};