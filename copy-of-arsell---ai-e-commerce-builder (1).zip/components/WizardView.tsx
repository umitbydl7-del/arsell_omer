import React, { useState, useRef, useEffect } from 'react';
import { 
  Lock, Loader2, Smartphone, Shirt, Dog, Home, Dumbbell, 
  HelpCircle, Info, ExternalLink, Check, Zap, ShieldCheck, 
  PartyPopper, ChevronRight, Terminal 
} from 'lucide-react';
import { Button } from './Button';
import { Category, Step, VerificationStatus } from '../types';

interface WizardViewProps {
  onBackToLanding: () => void;
}

export const WizardView: React.FC<WizardViewProps> = ({ onBackToLanding }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingLogs, setLoadingLogs] = useState<string[]>([]);
  const [shopifyUrl, setShopifyUrl] = useState('');
  const [isUrlSaved, setIsUrlSaved] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>('idle');
  const [progress, setProgress] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  const shopifyLink = "https://shopify.pxf.io/e1Og4Q";
  const downloadLink = "https://drive.google.com/uc?export=download&id=1gyMtrZe1dFlEVoajT8oFFT9yF-CGy6a7";

  const steps: Step[] = [
    { title: "Kategori & Konsept", desc: "Niş belirleme" },
    { title: "Altyapı Kurulumu", desc: "Shopify hesabı" },
    { title: "Sistem Entegrasyonu", desc: "API bağlantısı" },
    { title: "Plan Aktivasyonu", desc: "3 Aylık avantaj" },
    { title: "Finalizasyon", desc: "Teslimat" }
  ];

  const categories: Category[] = [
    { id: 'elektronik', icon: <Smartphone size={28} />, label: 'Elektronik', sub: 'Teknoloji & Gadget' },
    { id: 'kiyafet', icon: <Shirt size={28} />, label: 'Moda', sub: 'Giyim & Aksesuar' },
    { id: 'evcil', icon: <Dog size={28} />, label: 'Petshop', sub: 'Evcil Hayvan' },
    { id: 'ev', icon: <Home size={28} />, label: 'Ev & Yaşam', sub: 'Dekorasyon' },
    { id: 'spor', icon: <Dumbbell size={28} />, label: 'Spor', sub: 'Outdoor & Fitness' },
    { id: 'emin_degilim', icon: <HelpCircle size={28} />, label: 'Diğer', sub: 'Genel Mağaza' },
  ];

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeStep]);

  const simulateLoading = (callback: () => void) => {
    setIsLoading(true);
    setLoadingLogs([]);
    const messages = [
      "AI Motoru başlatılıyor...",
      "Sektör verileri analiz ediliyor...",
      "Rakip mağaza yapıları taranıyor...",
      "En uygun şablon seçiliyor...",
      "Optimizasyon tamamlandı."
    ];
    
    let i = 0;
    const interval = setInterval(() => {
      if (i < messages.length) {
        setLoadingLogs(prev => [...prev, messages[i]]);
        i++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setIsLoading(false);
          callback();
        }, 800);
      }
    }, 400); // Toplam süre yaklaşık 2-2.5 sn
  };

  const handleNext = () => {
    if (activeStep === 0 && !selectedCategory) return;
    if (activeStep === 2 && !isUrlSaved) return;

    simulateLoading(() => {
      if (activeStep < steps.length - 1) setActiveStep(prev => prev + 1);
    });
  };

  const handleVerifyAndDownload = () => {
    setVerificationStatus('verifying');
    setProgress(0);
    const interval = setInterval(() => setProgress(p => (p >= 100 ? 100 : p + Math.random() * 8)), 200);
    setTimeout(() => { clearInterval(interval); setVerificationStatus('downloading'); }, 3000);
    setTimeout(() => {
        try {
          const hiddenLink = document.createElement('a');
          hiddenLink.href = downloadLink;
          hiddenLink.style.display = 'none';
          document.body.appendChild(hiddenLink);
          hiddenLink.click();
          document.body.removeChild(hiddenLink);
        } catch (e) { 
          console.error("Otomatik indirme başlatılamadı.", e); 
        }
        setVerificationStatus('completed');
    }, 6000);
  };

  return (
    <div className="animate-fade-in-up pb-12 w-full">
      <div className="flex flex-col lg:flex-row gap-8 h-full max-w-[1500px] mx-auto" ref={scrollRef}>
        
        {/* SIDEBAR */}
        <div className="w-full lg:w-80 flex-shrink-0">
          <div className="sticky top-28 bg-[#0a0a0a]/50 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
              <h3 className="text-[11px] font-bold text-gray-500 uppercase tracking-[0.2em] mb-8 pl-1">İlerleme</h3>
              <div className="space-y-0 relative border-l border-white/10 ml-3">
                {steps.map((step, i) => (
                  <div key={i} className={`relative pl-8 py-4 transition-all duration-500 group ${i === activeStep ? 'opacity-100' : 'opacity-40'}`}>
                      {/* Active Indicator */}
                      <div className={`absolute left-[-2px] top-0 bottom-0 w-[3px] rounded-full transition-all duration-500 ${i === activeStep ? 'bg-blue-500 shadow-[0_0_15px_#3b82f6]' : 'bg-transparent'}`}></div>
                      <div className="flex flex-col">
                        <span className={`text-sm font-bold transition-colors ${i === activeStep ? 'text-white' : 'text-gray-400'}`}>{step.title}</span>
                        <span className="text-[10px] text-gray-600 mt-1 font-medium">{step.desc}</span>
                      </div>
                  </div>
                ))}
              </div>
              <div className="mt-8 pt-6 border-t border-white/5 flex items-center gap-3 opacity-70">
                <div className="p-1.5 rounded bg-green-500/10 text-green-500"><Lock size={12}/></div>
                <span className="text-[10px] text-gray-400 font-mono tracking-wider">SSL SECURED</span>
              </div>
          </div>
        </div>

        {/* CONTENT */}
        <div className="flex-1 min-h-[600px] flex flex-col">
            {isLoading ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8">
                <div className="bg-black/50 border border-white/10 rounded-xl p-6 w-full max-w-md font-mono text-xs shadow-2xl backdrop-blur-md">
                  <div className="flex items-center gap-2 mb-4 border-b border-white/10 pb-2">
                    <Terminal size={14} className="text-blue-500" />
                    <span className="text-gray-400">arsell-ai-terminal --v2.0</span>
                  </div>
                  <div className="space-y-2 h-40 overflow-hidden flex flex-col justify-end">
                     {loadingLogs.map((log, i) => (
                       <div key={i} className="text-green-400/80 animate-fade-in-up">
                         <span className="text-blue-500 mr-2">➜</span>
                         {log}
                       </div>
                     ))}
                     <div className="animate-pulse text-blue-500">_</div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 bg-[#0a0a0a]/80 backdrop-blur-md border border-white/10 rounded-3xl p-8 lg:p-12 shadow-2xl relative overflow-hidden flex flex-col">
                {/* Dynamic Background Glow */}
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/5 blur-[120px] -z-10 pointer-events-none"></div>

                <div className="flex-1">
                  {/* STEP 1: Categories */}
                  {activeStep === 0 && (
                    <div>
                      <div className="mb-10">
                        <h2 className="text-3xl font-bold text-white mb-2">Mağaza Kategorisi</h2>
                        <p className="text-gray-400">Sektörünüze en uygun tasarımı belirleyelim.</p>
                      </div>
                      <div className="grid grid-cols-2 lg:grid-cols-3 gap-5">
                        {categories.map((cat) => (
                          <button key={cat.id} onClick={() => setSelectedCategory(cat.id)}
                            className={`p-6 rounded-2xl border flex flex-col items-center text-center gap-4 transition-all duration-300 group relative overflow-hidden
                              ${selectedCategory === cat.id 
                                ? 'bg-white text-black border-white shadow-[0_0_40px_rgba(255,255,255,0.2)] scale-[1.02]' 
                                : 'bg-white/[0.03] border-white/5 text-gray-400 hover:bg-white/[0.06] hover:border-white/20'
                              }`}
                          >
                            <div className={`transform transition-transform duration-500 ${selectedCategory === cat.id ? 'scale-110' : 'group-hover:scale-110'}`}>{cat.icon}</div>
                            <div>
                              <span className="block text-sm font-bold uppercase tracking-wider">{cat.label}</span>
                              <span className={`text-[10px] block mt-1 ${selectedCategory === cat.id ? 'text-gray-600' : 'text-gray-600'}`}>{cat.sub}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* STEP 2: Shopify Account */}
                  {activeStep === 1 && (
                    <div className="max-w-xl mx-auto text-center lg:text-left">
                      <h2 className="text-3xl font-bold text-white mb-4">Hesap Kurulumu</h2>
                      <p className="text-gray-400 mb-8">Shopify altyapısı üzerinde güvenli mağazanızı oluşturun.</p>
                      <div className="bg-blue-500/10 border border-blue-500/20 p-6 rounded-2xl flex gap-4 text-blue-200 text-sm text-left mb-8">
                        <Info size={24} className="flex-shrink-0 text-blue-400" />
                        <p className="leading-relaxed">Açılan pencerede <strong>"Skip All"</strong> diyerek soruları hızlıca geçebilirsiniz. Kayıt sonrası buraya dönmeyi unutmayın.</p>
                      </div>
                      <Button onClick={() => window.open(shopifyLink, '_blank')} className="w-full py-5 text-lg justify-center shadow-blue-900/20">
                        Shopify'e Erişin <ExternalLink size={20} />
                      </Button>
                    </div>
                  )}

                  {/* STEP 3: Integration */}
                  {activeStep === 2 && (
                    <div className="max-w-2xl mx-auto">
                      <h2 className="text-3xl font-bold text-white mb-2">Entegrasyon</h2>
                      <p className="text-gray-400 mb-8">Mağaza URL'nizi girerek bağlantıyı sağlayın.</p>
                      <div className="rounded-2xl overflow-hidden border border-white/10 bg-black mb-8 shadow-2xl relative group">
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent z-10 pointer-events-none"></div>
                        <img src="https://i.hizliresim.com/qzj65fd.png" className="w-full opacity-80 group-hover:opacity-100 transition-opacity duration-700" alt="Demo" />
                        <div className="absolute bottom-4 left-4 z-20 flex gap-2">
                          <div className="w-2 h-2 rounded-full bg-red-500"></div><div className="w-2 h-2 rounded-full bg-yellow-500"></div><div className="w-2 h-2 rounded-full bg-green-500"></div>
                        </div>
                      </div>
                      <div className="relative">
                        <input type="text" value={shopifyUrl} onChange={(e) => setShopifyUrl(e.target.value)} placeholder="https://magaza-adiniz.myshopify.com/admin" 
                          className="w-full bg-[#050505] border border-white/20 rounded-xl pl-6 pr-32 py-5 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none font-mono text-sm transition-all" />
                        <button onClick={() => { setShopifyUrl(shopifyUrl); setIsUrlSaved(true); }} className={`absolute right-2 top-2 bottom-2 px-6 rounded-lg font-bold text-xs transition-all ${isUrlSaved ? 'bg-green-500 text-black' : 'bg-white text-black hover:bg-gray-200'}`}>
                          {isUrlSaved ? 'BAĞLANDI' : 'KAYDET'}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* STEP 4: Plan */}
                  {activeStep === 3 && (
                    <div className="max-w-4xl mx-auto">
                      <h2 className="text-3xl font-bold text-white mb-2">Plan Aktivasyonu</h2>
                      <p className="text-gray-400 mb-8">3 ay boyunca 1$ özel teklifini etkinleştirin.</p>
                      <div className="grid lg:grid-cols-2 gap-8 items-center bg-white/[0.02] border border-white/5 rounded-3xl p-8">
                        <div className="space-y-6">
                          <h3 className="text-lg font-bold text-white">Adımlar:</h3>
                          <ul className="space-y-4">
                            {["Butona tıkla ve Shopify'a dön.", "Planlar arasından 'Basic' paketini seç.", "Ödeme yöntemini güvenli şekilde ekle."].map((item, idx) => (
                              <li key={idx} className="flex gap-4 items-center text-gray-300 text-sm">
                                <div className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center font-bold text-white text-xs">{idx + 1}</div> {item}
                              </li>
                            ))}
                          </ul>
                          <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20 text-green-400 text-sm font-bold flex items-center gap-3">
                              <Check size={18} /> İlk 3 ay sadece 1$ ödersiniz.
                          </div>
                        </div>
                        <div className="relative group cursor-pointer overflow-hidden rounded-2xl border border-white/10" onClick={() => window.open(shopifyLink, '_blank')}>
                          <div className="absolute inset-0 bg-blue-600/20 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center justify-center"><ExternalLink className="text-white drop-shadow-lg" /></div>
                          <img src="https://i.hizliresim.com/3wxd3gp.png" className="w-full transform group-hover:scale-105 transition-transform duration-700" alt="Plan" />
                        </div>
                      </div>
                      <Button onClick={() => window.open(shopifyLink, '_blank')} variant="gradient" className="w-full mt-8 py-5 text-lg shadow-blue-900/30">
                        Planı Şimdi Etkinleştir <Zap size={20} fill="currentColor" />
                      </Button>
                    </div>
                  )}

                  {/* STEP 5: Finalization */}
                  {activeStep === 4 && (
                    <div className="text-center h-full flex flex-col justify-center items-center py-12">
                      {verificationStatus === 'idle' && (
                        <div className="animate-fade-in-up">
                          <div className="w-32 h-32 bg-gradient-to-br from-white/10 to-transparent rounded-full flex items-center justify-center mx-auto mb-10 border border-white/10 shadow-[0_0_60px_rgba(255,255,255,0.1)] relative">
                            <div className="absolute inset-0 border border-white/20 rounded-full animate-ping opacity-20"></div>
                            <ShieldCheck size={64} className="text-white"/>
                          </div>
                          <h2 className="text-4xl font-bold text-white mb-4">Her Şey Hazır!</h2>
                          <p className="text-gray-400 mb-12 text-lg max-w-md mx-auto">Tüm yapılandırmalar tamamlandı. Mağazanızı oluşturmak için son onayı verin.</p>
                          <Button onClick={handleVerifyAndDownload} className="px-16 py-6 text-xl rounded-full mx-auto">Doğrula & İndir</Button>
                        </div>
                      )}
                      {(verificationStatus === 'verifying' || verificationStatus === 'downloading') && (
                        <div className="w-full max-w-md animate-fade-in-up">
                          <div className="flex justify-between text-xs font-mono text-blue-400 mb-4 tracking-widest">
                            <span>SİSTEM İŞLENİYOR</span><span>{Math.round(progress)}%</span>
                          </div>
                          <div className="h-2 bg-[#1a1a1a] rounded-full overflow-hidden mb-8 border border-white/10">
                            <div className="h-full bg-gradient-to-r from-blue-600 via-purple-500 to-blue-600 bg-[length:200%_100%] animate-[shimmer_2s_infinite]" style={{width: `${progress}%`}}></div>
                          </div>
                          <div className="flex items-center justify-center gap-3 text-sm text-gray-400">
                              <Loader2 size={16} className="animate-spin text-blue-500"/>
                              {verificationStatus === 'verifying' ? 'API Bağlantıları kontrol ediliyor...' : 'Premium tema paketleniyor...'}
                          </div>
                        </div>
                      )}
                      {verificationStatus === 'completed' && (
                        <div className="animate-fade-in-up">
                          <div className="w-32 h-32 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-8 border border-green-500/30 shadow-[0_0_60px_rgba(34,197,94,0.3)]">
                            <PartyPopper size={64} className="text-green-500" />
                          </div>
                          <h2 className="text-4xl font-bold text-white mb-4">Tebrikler!</h2>
                          <p className="text-gray-300 mb-12 text-lg">Arsell Premium temanız başarıyla indirildi.<br/>Shopify paneline yükleyerek satışa başlayabilirsiniz.</p>
                          <div className="bg-white/5 border border-white/10 p-4 rounded-xl mb-8 text-sm text-gray-400">
                            İndirme başlamadı mı? <a href={downloadLink} target="_blank" className="text-white underline hover:text-blue-400">Manuel İndir</a>
                          </div>
                          <button onClick={() => window.location.reload()} className="text-gray-500 hover:text-white transition-colors text-sm">Başa Dön</button>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* NAVIGATION */}
                {verificationStatus === 'idle' && activeStep !== 4 && (
                  <div className="flex justify-between items-center mt-8 pt-8 border-t border-white/10">
                    <button onClick={() => setActiveStep(p => p - 1)} disabled={activeStep === 0} className={`px-6 py-3 rounded-xl text-sm font-bold text-gray-500 hover:text-white hover:bg-white/5 transition-colors ${activeStep===0 ? 'invisible':''}`}>Geri Dön</button>
                    <Button onClick={handleNext} disabled={(activeStep===0 && !selectedCategory) || (activeStep===2 && !isUrlSaved)} className="px-8">
                      Devam Et <ChevronRight size={18} />
                    </Button>
                  </div>
                )}
              </div>
            )}
        </div>
      </div>
    </div>
  );
};